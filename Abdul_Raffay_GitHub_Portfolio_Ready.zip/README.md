# Abdul Raffay | Technical Portfolio

Computer Science graduate portfolio covering software development, databases,
data analysis and technical research.

## Included evidence

- React and JavaScript application component
- PostgreSQL database schema
- R statistical-analysis workflow
- SAS analysis workflow
- Three recruiter-focused CV versions
- Static portfolio homepage
- Project documentation for the dashboard and analysis workflows

## Core technologies

Python, JavaScript, React, SQL, PostgreSQL, SQLite, R, SAS, SPSS, Power BI,
Tableau, HTML and CSS.

## GitHub profile

https://github.com/rafey2003

## Suggested repository

Create a public repository named `abdul-raffay-portfolio` and upload the
contents of this folder.

The code samples are presented as technical portfolio evidence. Private
datasets, credentials and confidential personal information are not included.
