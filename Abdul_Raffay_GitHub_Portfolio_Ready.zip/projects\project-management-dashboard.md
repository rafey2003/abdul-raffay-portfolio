# Project Management Dashboard Prototype

## Overview

A React-based project-management interface for organising users, workspaces,
projects, tasks, reporting and project communication.

## Technical evidence

- React and JavaScript component logic
- Client-side state for authentication, selected projects, tasks and messages
- REST-style API integration
- WebSocket subscription for project messages
- PostgreSQL schema covering users, workspaces, projects, tasks, messages,
  presence and notifications

## Included files

- [`project-dashboard-app.jsx`](../assets/code/project-dashboard-app.jsx)
- [`database-schema.sql`](../assets/code/database-schema.sql)

## What I learned

The project required coordinating related state across multiple screens and
keeping the interface responsive to authentication, project selection and
real-time message events.
