# Selected Projects

This folder contains concise technical descriptions of the public evidence
included in the portfolio package.

- [Project Management Dashboard](./project-management-dashboard.md)
- [Data Analysis Workflows](./data-analysis-workflows.md)

The repository includes source-code and schema examples only. Private
datasets, credentials and confidential client material are excluded.
