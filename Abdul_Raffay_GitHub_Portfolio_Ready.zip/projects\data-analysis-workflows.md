# Data Analysis Workflows

## Overview

A collection of repeatable R and SAS workflows for importing, checking,
transforming and analysing structured data.

## R workflow

The R workflow covers:

- Data import and column validation
- Missing-value counts and descriptive statistics
- Power analysis
- Histograms, density plots, boxplots and pairwise visualisations
- Hypothesis testing and logistic regression
- Confidence intervals and confounder checks

Evidence: [`statistical-analysis.r`](../assets/code/statistical-analysis.r)

## SAS workflow

The SAS workflow covers:

- Importing three structured input datasets
- Dataset inspection with `PROC CONTENTS`
- Descriptive summaries with `PROC MEANS`
- Distribution and boxplot analysis
- SQL joins and merged-table preparation
- ANOVA and MANOVA
- Clustering and principal-component analysis

Evidence: [`sas-analysis.sas`](../assets/code/sas-analysis.sas)

The public code package does not include the source datasets.
