﻿# ENS4403 assignment analysis script
household_path <- "data/household_info.csv"
output_folder <- "ENS4403_results"
id_var <- "resp_id"
hh_var <- "hh_size"
response_var <- "agri_survey"

pkgs <- c("tidyverse", "readr", "pwr", "GGally", "broom", "car", "DHARMa")
for (p in pkgs) if (!requireNamespace(p, quietly = TRUE)) install.packages(p)
library(tidyverse); library(readr); library(pwr); library(GGally); library(broom); library(car)

if (!dir.exists(output_folder)) dir.create(output_folder)

hh <- tryCatch(read_csv(household_path, show_col_types = FALSE),
               error = function(e) stop("Cannot read household file: ", e$message))

cat("Rows:", nrow(hh), "Cols:", ncol(hh), "\n")
cat("Columns:\n"); print(colnames(hh))

if (!(hh_var %in% names(hh))) stop("Household size column not found: ", hh_var)

hh <- hh %>% mutate(!!hh_var := as.numeric(.data[[hh_var]]))

has_response <- response_var %in% names(hh)
if (has_response) {
  vals <- sort(unique(na.omit(hh[[response_var]])))
  if (is.numeric(hh[[response_var]]) && all(vals %in% c(0,1))) {
    hh[[response_var]] <- factor(ifelse(hh[[response_var]] == 1, "Yes", "No"), levels = c("No","Yes"))
  } else {
    hh[[response_var]] <- as.factor(hh[[response_var]])
    hh[[response_var]] <- factor(ifelse(tolower(as.character(hh[[response_var]])) %in% c("yes","y","1"), "Yes", "No"),
                                 levels = c("No","Yes"))
  }
  cat("Response levels:", paste(levels(hh[[response_var]]), collapse = ", "), "\n")
} else {
  cat("agri_survey not found; group comparisons and logistic regression will be skipped.\n")
}

missing_counts <- sapply(hh[c(hh_var, if (has_response) response_var)], function(x) sum(is.na(x)))
write_csv(as.data.frame(missing_counts), file.path(output_folder, "missing_counts.csv"))

pwr_res <- pwr.t.test(d = 0.3, power = 0.8, sig.level = 0.05,
                     type = "two.sample", alternative = "two.sided")
pwr_out <- tibble(test = "pwr_t_test", d = 0.3, power = 0.8, n_per_group = pwr_res$n, total = 2 * pwr_res$n)
write_csv(pwr_out, file.path(output_folder, "power_analysis.csv"))

p_hist <- ggplot(hh, aes(x = .data[[hh_var]])) + geom_histogram(binwidth = 1, fill = "steelblue", color = "white") +
  labs(x = "Household size", y = "Count", title = "Histogram of household size") + theme_minimal()
ggsave(file.path(output_folder, "hist_hh_size.png"), p_hist, width = 7, height = 4)

p_density <- ggplot(hh, aes(x = .data[[hh_var]])) + geom_density(fill = "lightblue", alpha = 0.5, na.rm = TRUE) +
  labs(x = "Household size", y = "Density", title = "Density of household size") + theme_minimal()
ggsave(file.path(output_folder, "density_hh_size.png"), p_density, width = 7, height = 4)

if (has_response) {
  p_bar <- ggplot(hh, aes(x = .data[[response_var]])) + geom_bar(fill = "coral") +
    labs(x = "Participated", y = "Count", title = "Agricultural survey participation") + theme_minimal()
  ggsave(file.path(output_folder, "bar_response.png"), p_bar, width = 5, height = 4)

  p_box <- ggplot(hh, aes(x = .data[[response_var]], y = .data[[hh_var]])) +
    geom_boxplot() + geom_jitter(width = 0.1, alpha = 0.4) +
    labs(x = "Participation", y = "Household size", title = "Household size by participation") + theme_minimal()
  ggsave(file.path(output_folder, "box_hh_by_response.png"), p_box, width = 6, height = 4)

  p_hyp <- ggplot(hh, aes(x = .data[[response_var]], y = .data[[hh_var]])) +
    geom_boxplot(alpha = 0.6) + stat_summary(fun = mean, geom = "point", color = "red", size = 3) +
    labs(title = "Hypothesis: household size by participation", x = "Participation", y = "Household size") + theme_minimal()
  ggsave(file.path(output_folder, "hypothesis_plot.png"), p_hyp, width = 6, height = 4)
}

n_non_na <- sum(!is.na(hh[[hh_var]]))
get_mode <- function(x) { ux <- unique(na.omit(x)); ux[which.max(tabulate(match(x, ux)))] }
desc_tbl <- tibble(
  n = n_non_na,
  mean = mean(hh[[hh_var]], na.rm = TRUE),
  median = median(hh[[hh_var]], na.rm = TRUE),
  mode = get_mode(hh[[hh_var]]),
  variance = var(hh[[hh_var]], na.rm = TRUE),
  sd = sd(hh[[hh_var]], na.rm = TRUE),
  se = sd / sqrt(n_non_na)
)
write_csv(desc_tbl, file.path(output_folder, "desc_hh_size.csv"))

cont_vars <- hh %>% select(where(is.numeric))
if (ncol(cont_vars) >= 2) {
  p_pairs <- tryCatch(GGally::ggpairs(cont_vars), error = function(e) NULL)
  if (!is.null(p_pairs)) ggsave(file.path(output_folder, "pairs_numeric.png"), p_pairs, width = 10, height = 10)
}

if (has_response) {
  g0 <- hh %>% filter(.data[[response_var]] == levels(hh[[response_var]])[1]) %>% pull(.data[[hh_var]])
  g1 <- hh %>% filter(.data[[response_var]] == levels(hh[[response_var]])[2]) %>% pull(.data[[hh_var]])
  t_res <- tryCatch(t.test(as.formula(paste(hh_var, "~", response_var)), data = hh), error = function(e) e)
  if (inherits(t_res, "error")) {
    w_res <- wilcox.test(as.formula(paste(hh_var, "~", response_var)), data = hh)
    write_csv(broom::tidy(w_res), file.path(output_folder, "wilcox_results.csv"))
  } else {
    write_csv(broom::tidy(t_res), file.path(output_folder, "t_test_results.csv"))
  }

  model1 <- glm(as.formula(paste(response_var, "~", hh_var)), data = hh, family = binomial)
  write_csv(broom::tidy(model1, conf.int = TRUE, exponentiate = TRUE), file.path(output_folder, "logit_univariable.csv"))
  or_ci1 <- data.frame(exp_coef = exp(coef(model1)), exp_confint = exp(confint(model1)))
  write_csv(or_ci1, file.path(output_folder, "logit_univariable_or_ci.csv"))

  potential_confounders <- c("dist2park", "site", "fokontany", "hhd_ethni", "hh_age")
  present_conf <- potential_confounders[potential_confounders %in% names(hh)]
  if (length(present_conf) > 0) {
    formula_mv <- as.formula(paste(response_var, "~", paste(c(hh_var, present_conf), collapse = " + ")))
    model2 <- glm(formula_mv, data = hh, family = binomial)
    write_csv(broom::tidy(model2, conf.int = TRUE, exponentiate = TRUE), file.path(output_folder, "logit_multivariable.csv"))
    or_ci2 <- data.frame(exp_coef = exp(coef(model2)), exp_confint = exp(confint(model2)))
    write_csv(or_ci2, file.path(output_folder, "logit_multivariable_or_ci.csv"))
    vif_res <- tryCatch(car::vif(model2), error = function(e) NULL)
    if (!is.null(vif_res)) write_csv(as.data.frame(vif_res), file.path(output_folder, "vif_multivariable.csv"))
    if (requireNamespace("DHARMa", quietly = TRUE)) {
      sim <- tryCatch(DHARMa::simulateResiduals(model2, plot = FALSE), error = function(e) NULL)
      if (!inherits(sim, "try-error") && !is.null(sim)) {
        png(file.path(output_folder, "dharma_residuals.png"), width = 800, height = 600)
        plot(sim)
        dev.off()
      }
    }
  }
}

summary_lines <- c()
summary_lines <- c(summary_lines, paste0("Data file: ", household_path))
summary_lines <- c(summary_lines, paste0("Rows: ", nrow(hh), " Columns: ", ncol(hh)))
summary_lines <- c(summary_lines, "Descriptive statistics for household size:")
summary_lines <- c(summary_lines, capture.output(print(desc_tbl)))
if (has_response) {
  summary_lines <- c(summary_lines, "")
  summary_lines <- c(summary_lines, "Response levels:")
  summary_lines <- c(summary_lines, paste(levels(hh[[response_var]]), collapse = ", "))
  if (exists("t_res") && !inherits(t_res, "error")) summary_lines <- c(summary_lines, capture.output(print(t_res)))
  if (exists("model1")) summary_lines <- c(summary_lines, capture.output(print(summary(model1))))
  if (exists("model2")) summary_lines <- c(summary_lines, capture.output(print(summary(model2))))
} else {
  summary_lines <- c(summary_lines, "agri_survey not present; descriptive analysis only.")
}
writeLines(summary_lines, con = file.path(output_folder, "analysis_summary.txt"))

cat("Results saved to", normalizePath(output_folder), "\n")
print(list.files(output_folder, full.names = TRUE))
