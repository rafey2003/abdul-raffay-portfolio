﻿import { useEffect, useMemo, useState } from "react";
import API from "./api";

function App() {
  const [token, setToken] = useState(localStorage.getItem("token") || "");
  const [currentUser, setCurrentUser] = useState(null);
  const [users, setUsers] = useState([]);
  const [projects, setProjects] = useState([]);
  const [tasks, setTasks] = useState([]);
  const [dashboard, setDashboard] = useState(null);
  const [messages, setMessages] = useState([]);

  const [selectedProjectId, setSelectedProjectId] = useState("");
  const [chatText, setChatText] = useState("");
  const [newUser, setNewUser] = useState({ name: "", email: "", password: "", role: "member" });
  const [newProject, setNewProject] = useState({ name: "", description: "", ownerUserId: "" });
  const [newTask, setNewTask] = useState({ title: "", description: "", assigneeUserId: "", status: "TODO" });

  const clearSession = () => {
    setToken("");
    setCurrentUser(null);
    localStorage.removeItem("token");
  };

  const fetchAuth = async (url, options = {}) => {
    const headers = {
      ...(options.headers || {}),
      // Authentication wiring omitted from this public portfolio sample.
    };
    const res = await fetch(url, { ...options, headers });
    if (res.status === 401) {
      clearSession();
    }
    return res;
  };

  const selectedProject = useMemo(
    () => projects.find((project) => String(project.id) === String(selectedProjectId)),
    [projects, selectedProjectId]
  );

  const loadBaseData = async () => {
    const [usersRes, projectsRes] = await Promise.all([
      fetchAuth(`${API.users}/users`),
      fetchAuth(`${API.projects}/projects`)
    ]);
    if (!usersRes.ok || !projectsRes.ok) {
      return;
    }
    setUsers(await usersRes.json());
    const loadedProjects = await projectsRes.json();
    setProjects(loadedProjects);
    if (!selectedProjectId && loadedProjects.length > 0) {
      setSelectedProjectId(loadedProjects[0].id);
    }
  };

  const loadTasks = async (projectId) => {
    if (!projectId) {
      setTasks([]);
      return;
    }
    const res = await fetchAuth(`${API.tasks}/tasks/project/${projectId}`);
    if (!res.ok) {
      return;
    }
    setTasks(await res.json());
  };

  const loadDashboard = async () => {
    const res = await fetchAuth(`${API.reporting}/dashboard`);
    if (!res.ok) {
      return;
    }
    setDashboard(await res.json());
  };

  const loadMessages = async (projectId) => {
    if (!projectId) {
      setMessages([]);
      return;
    }
    const res = await fetchAuth(`${API.chat}/messages?projectId=${projectId}`);
    if (!res.ok) {
      return;
    }
    setMessages(await res.json());
  };

  useEffect(() => {
    if (!token) {
      return;
    }
    loadBaseData();
    loadDashboard();
    const id = setInterval(() => {
      loadBaseData();
      loadDashboard();
    }, 5000);
    return () => clearInterval(id);
  }, [token]);

  useEffect(() => {
    loadTasks(selectedProjectId);
    loadMessages(selectedProjectId);
  }, [selectedProjectId]);

  useEffect(() => {
    if (!selectedProjectId) {
      return;
    }

    const ws = new WebSocket(API.ws);
    ws.onopen = () => {
      ws.send(JSON.stringify({ type: "subscribe", projectId: selectedProjectId }));
    };
    ws.onmessage = (event) => {
      const msg = JSON.parse(event.data);
      if (msg.type === "message") {
        setMessages((prev) => [...prev, msg.payload]);
      }
    };
    return () => ws.close();
  }, [selectedProjectId]);

  const handleCreateUser = async (e) => {
    e.preventDefault();
    const res = await fetch(`${API.users}/auth/register`, {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify(newUser)
    });
    if (!res.ok) {
      return;
    }
    const data = await res.json();
    if (!token && data.token) {
      setToken(data.token);
      setCurrentUser(data.user);
      localStorage.setItem("token", data.token);
    }
    setNewUser({ name: "", email: "", password: "", role: "member" });
    loadBaseData();
  };

  const handleLogin = async (e) => {
    e.preventDefault();
    const res = await fetch(`${API.users}/auth/login`, {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify({ email: newUser.email, password: newUser.password })
    });
    if (!res.ok) {
      return;
    }
    const data = await res.json();
    setToken(data.token);
    setCurrentUser(data.user);
    localStorage.setItem("token", data.token);
  };

  const handleCreateProject = async (e) => {
    e.preventDefault();
    await fetchAuth(`${API.projects}/projects`, {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify({ ...newProject, ownerUserId: Number(newProject.ownerUserId) })
    });
    setNewProject({ name: "", description: "", ownerUserId: "" });
    loadBaseData();
  };

  const handleCreateTask = async (e) => {
    e.preventDefault();
    if (!selectedProjectId) {
      return;
    }
    await fetchAuth(`${API.tasks}/tasks`, {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify({
        ...newTask,
        projectId: Number(selectedProjectId),
        assigneeUserId: Number(newTask.assigneeUserId)
      })
    });
    setNewTask({ title: "", description: "", assigneeUserId: "", status: "TODO" });
    loadTasks(selectedProjectId);
    loadDashboard();
  };

  const handleStatusChange = async (taskId, status) => {
    await fetchAuth(`${API.tasks}/tasks/${taskId}/status`, {
      method: "PATCH",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify({ status })
    });
    loadTasks(selectedProjectId);
    loadDashboard();
  };

  const handleSendMessage = async (e) => {
    e.preventDefault();
    if (!selectedProjectId || !chatText || users.length === 0) {
      return;
    }
    await fetchAuth(`${API.chat}/messages`, {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify({
        projectId: Number(selectedProjectId),
        userId: users[0].id,
        text: chatText
      })
    });
    setChatText("");
  };

  if (!token) {
    return (
      <div className="page">
        <header className="hero">
          <h1>Project Orbit</h1>
          <p>Authenticate to access workspace data via API gateway.</p>
        </header>
        <main className="grid">
          <section className="card">
            <h2>Register</h2>
            <form onSubmit={handleCreateUser}>
              <input placeholder="Name" value={newUser.name} onChange={(e) => setNewUser({ ...newUser, name: e.target.value })} required />
              <input placeholder="Email" type="email" value={newUser.email} onChange={(e) => setNewUser({ ...newUser, email: e.target.value })} required />
              <input placeholder="Password" type="password" value={newUser.password} onChange={(e) => setNewUser({ ...newUser, password: e.target.value })} required />
              <select value={newUser.role} onChange={(e) => setNewUser({ ...newUser, role: e.target.value })}>
                <option value="member">member</option>
                <option value="viewer">viewer</option>
                <option value="admin">admin</option>
              </select>
              <button type="submit">Register</button>
            </form>
          </section>
          <section className="card">
            <h2>Login</h2>
            <form onSubmit={handleLogin}>
              <input placeholder="Email" type="email" value={newUser.email} onChange={(e) => setNewUser({ ...newUser, email: e.target.value })} required />
              <input placeholder="Password" type="password" value={newUser.password} onChange={(e) => setNewUser({ ...newUser, password: e.target.value })} required />
              <button type="submit">Login</button>
            </form>
          </section>
        </main>
      </div>
    );
  }

  return (
    <div className="page">
      <header className="hero">
        <h1>Project Orbit</h1>
        <p>Distributed collaboration prototype with local-only storage.</p>
        <button className="logout" onClick={clearSession}>Logout</button>
      </header>

      <main className="grid">
        <section className="card">
          <h2>Create User</h2>
          <form onSubmit={handleCreateUser}>
            <input
              placeholder="Name"
              value={newUser.name}
              onChange={(e) => setNewUser({ ...newUser, name: e.target.value })}
              required
            />
            <input
              placeholder="Email"
              value={newUser.email}
              onChange={(e) => setNewUser({ ...newUser, email: e.target.value })}
              required
              type="email"
            />
            <input
              placeholder="Password"
              value={newUser.password}
              onChange={(e) => setNewUser({ ...newUser, password: e.target.value })}
              required
              type="password"
            />
            <select value={newUser.role} onChange={(e) => setNewUser({ ...newUser, role: e.target.value })}>
              <option value="member">member</option>
              <option value="viewer">viewer</option>
              <option value="admin">admin</option>
            </select>
            <button type="submit">Add User</button>
          </form>
        </section>

        <section className="card">
          <h2>Create Project</h2>
          <form onSubmit={handleCreateProject}>
            <input
              placeholder="Project name"
              value={newProject.name}
              onChange={(e) => setNewProject({ ...newProject, name: e.target.value })}
              required
            />
            <input
              placeholder="Description"
              value={newProject.description}
              onChange={(e) => setNewProject({ ...newProject, description: e.target.value })}
            />
            <select
              value={newProject.ownerUserId}
              onChange={(e) => setNewProject({ ...newProject, ownerUserId: e.target.value })}
              required
            >
              <option value="">Owner</option>
              {users.map((user) => (
                <option key={user.id} value={user.id}>
                  {user.name}
                </option>
              ))}
            </select>
            <button type="submit">Create Project</button>
          </form>
        </section>

        <section className="card wide">
          <h2>Projects</h2>
          <div className="chips">
            {projects.map((project) => (
              <button
                key={project.id}
                className={String(project.id) === String(selectedProjectId) ? "chip active" : "chip"}
                onClick={() => setSelectedProjectId(project.id)}
              >
                {project.name}
              </button>
            ))}
          </div>
        </section>

        <section className="card">
          <h2>Create Task</h2>
          <form onSubmit={handleCreateTask}>
            <input
              placeholder="Title"
              value={newTask.title}
              onChange={(e) => setNewTask({ ...newTask, title: e.target.value })}
              required
            />
            <input
              placeholder="Description"
              value={newTask.description}
              onChange={(e) => setNewTask({ ...newTask, description: e.target.value })}
            />
            <select
              value={newTask.assigneeUserId}
              onChange={(e) => setNewTask({ ...newTask, assigneeUserId: e.target.value })}
              required
            >
              <option value="">Assignee</option>
              {users.map((user) => (
                <option key={user.id} value={user.id}>
                  {user.name}
                </option>
              ))}
            </select>
            <select value={newTask.status} onChange={(e) => setNewTask({ ...newTask, status: e.target.value })}>
              <option value="TODO">TODO</option>
              <option value="IN_PROGRESS">IN_PROGRESS</option>
              <option value="DONE">DONE</option>
            </select>
            <button type="submit">Add Task</button>
          </form>
        </section>

        <section className="card">
          <h2>Tasks in {selectedProject?.name || "No project"}</h2>
          <ul className="list">
            {tasks.map((task) => (
              <li key={task.id}>
                <div>
                  <strong>{task.title}</strong>
                  <p>{task.description}</p>
                </div>
                <select value={task.status} onChange={(e) => handleStatusChange(task.id, e.target.value)}>
                  <option value="TODO">TODO</option>
                  <option value="IN_PROGRESS">IN_PROGRESS</option>
                  <option value="DONE">DONE</option>
                </select>
              </li>
            ))}
          </ul>
        </section>

        <section className="card wide">
          <h2>Project Chat</h2>
          <div className="chatbox">
            {messages.map((msg) => (
              <p key={msg.id}>
                <span>User {msg.userId}:</span> {msg.text}
              </p>
            ))}
          </div>
          <form className="chat-form" onSubmit={handleSendMessage}>
            <input value={chatText} onChange={(e) => setChatText(e.target.value)} placeholder="Write a message" required />
            <button type="submit">Send</button>
          </form>
        </section>

        <section className="card wide">
          <h2>Dashboard</h2>
          {!dashboard ? (
            <p>Loading...</p>
          ) : (
            <>
              <p>
                {dashboard.projectCount} projects, {dashboard.taskCount} tasks total
              </p>
              <div className="stats">
                {Object.entries(dashboard.taskStatusBreakdown || {}).map(([key, value]) => (
                  <div key={key} className="stat">
                    <h3>{key}</h3>
                    <p>{value}</p>
                  </div>
                ))}
              </div>
            </>
          )}
        </section>
      </main>
    </div>
  );
}

export default App;

