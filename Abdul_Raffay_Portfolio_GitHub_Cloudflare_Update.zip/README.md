# Abdul Raffay | Technical Portfolio

Computer Science graduate portfolio covering software development, databases,
data analysis and technical research.

## Included evidence

- React and JavaScript application component
- PostgreSQL database schema
- R statistical-analysis workflow
- SAS analysis workflow
- Three recruiter-focused CV versions
- Static portfolio homepage

## Core technologies

Python, JavaScript, React, SQL, PostgreSQL, SQLite, R, SAS, SPSS, Power BI,
Tableau, HTML and CSS.

## Portfolio website

https://yellow-king-c0e0.zaheeraslam72.workers.dev/

## GitHub profile

https://github.com/rafey2003

The code samples are presented as technical portfolio evidence. Private
datasets, credentials and confidential personal information are not included.
