﻿
PROC IMPORT DATAFILE="data/sixth_form.csv"
    OUT=sixth_form_data
    DBMS=CSV
    REPLACE;
    GETNAMES=YES;
RUN;


PROC IMPORT DATAFILE="data/first_year.csv"
    OUT=fe_data
    DBMS=CSV
    REPLACE;
    GETNAMES=YES;
RUN;


PROC IMPORT DATAFILE="data/first_year_metrics.tab"
    OUT=fe_metrics_data
    DBMS=TAB
    REPLACE;
    GETNAMES=YES;
RUN;


PROC MEANS DATA=sixth_form_data N NMISS MIN MAX MEAN;
RUN;

PROC MEANS DATA=fe_data N NMISS MIN MAX MEAN;
RUN;

PROC MEANS DATA=fe_metrics_data N NMISS MIN MAX MEAN;
RUN;
/*---------------------------------------------------------------------------------------------*/


OPTIONS NONOTES NOSTIMER NOSOURCE NOSYNTAXCHECK;


PROC CONTENTS DATA=sixth_form_data; RUN;
PROC CONTENTS DATA=fe_data; RUN;
PROC CONTENTS DATA=fe_metrics_data; RUN;


PROC MEANS DATA=sixth_form_data N MEAN STD MIN MAX;
    VAR Learners1 Learners2 "Learners 3"n; 
RUN;

PROC MEANS DATA=fe_data N MEAN STD MIN MAX;
    VAR Learners "Total CH Year 1"n "Total CH Year 2"n "Total CH Year 3"n;
RUN;


PROC MEANS DATA=fe_metrics_data N MEAN STD MIN MAX;
    VAR GradPR VAF;
RUN;



OPTIONS NONOTES NOSTIMER NOSOURCE NOSYNTAXCHECK;
/*---------------------------------------------------------------------------------------------*/
PROC UNIVARIATE DATA=sixth_form_data;
    HISTOGRAM / NORMAL;
RUN;

PROC UNIVARIATE DATA=fe_data;
    HISTOGRAM / NORMAL;
RUN;

PROC UNIVARIATE DATA=fe_metrics_data;
    HISTOGRAM / NORMAL;
RUN;
/*---------------------------------------------------------------------------------------------*/
PROC SGPLOT DATA=sixth_form_data;
    VBOX "Learners1"n;
    VBOX "Learners2"n;
    VBOX "Learners 3"n;
RUN;

PROC SGPLOT DATA=fe_data;
    VBOX "Learners"n;
    VBOX "Total CH Year 1"n;
    VBOX "Total CH Year 2"n;
    VBOX "Total CH Year 3"n;
RUN;

PROC SGPLOT DATA=fe_metrics_data;
    VBOX "GradPR"n;
    VBOX "VAF"n;
RUN;
/*---------------------------------------------------------------------------------------------*/
PROC PRINT DATA=sixth_form_data (OBS=10);
RUN;

PROC PRINT DATA=fe_data (OBS=10);
RUN;

PROC PRINT DATA=fe_metrics_data (OBS=10);
RUN;
/*---------------------------------------------------------------------------------------------*/

proc sql;
    create table temp_merged as
    select 
        sf.*,          
        fm.ID,         
        fm.VAF         
    from sixth_form_data sf
    left join fe_metrics_data fm on sf.GradPR = fm.GradPR;
quit;

proc sql;
    create table merged_data as
    select 
        tm.*,          
        fe.*           
    from temp_merged tm
    left join fe_data fe on tm.ID = fe.ID;
quit;

proc print data=merged_data (obs=20); run; 
proc contents data=merged_data; run; 
/*---------------------------------------------------------------------------------------------*/
/*single anova*/
proc glm data=merged_data;
    class VAR10;
    model GradPR = VAR10;
    means VAR10 / tukey;
run;
/*clusetering*/

proc fastclus data=merged_data out=clusters maxclusters=3;
    var GradPR  VAF Learners;
run;
proc distance data=merged_data out=distances method=euclid;
    var interval(GradPR VAF Learners);
run;
/*manova*/
proc glm data=merged_data;
    class VAR10;
    model GradPR VAF = VAR10;
    manova h=_all_ / printe printh;
run;
/* Principal Component Analysis (PCA)*/
proc princomp data=merged_data out=pca_results plots=all;
    var GradPR VAF Learners;
run;







